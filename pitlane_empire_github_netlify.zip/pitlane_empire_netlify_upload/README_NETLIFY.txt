PITLANE EMPIRE — Netlify Upload
================================

WHAT THIS PACKAGE DOES
- Contains the current browser game as index.html, ready for a simple static Netlify Drop deployment.
- Keeps the current game and its existing browser/local save behavior.
- Includes the PITLANE 3065 code that was added to this version.

IMPORTANT LIMITATIONS
- This static deployment does NOT by itself activate Google login, online cloud saves, server-verified online gift codes, live player tracking, host/developer permissions, or the host-exclusive Senna McLaren.
- Browser/local saves normally remain in that browser/device. They do not automatically sync between devices.
- Do not put secret API keys or admin credentials in index.html.

PUBLISH QUICKLY
1. Open https://app.netlify.com/drop and sign in to Netlify.
2. Unzip pitlane_empire_netlify_upload.zip on your computer.
3. Drag the extracted folder (the folder containing index.html) onto the Netlify Drop page.
4. Wait for deployment and open the URL Netlify gives you.
5. Test the game in a private/incognito window and on another device if possible.

UPDATES LATER
- Replace index.html with the updated game file, then upload the folder again to the existing Netlify site, or connect a GitHub repository for automatic deployments.

FOR THE FULL ONLINE VERSION
Use the separate pitlane_empire_online_starter.zip project. That project needs Firebase configuration, Google Authentication, Firestore rules, Cloud Functions deployment and role setup. The current online starter is a scaffold and still needs full game-save synchronization and the host-only car integration before those features can be considered complete.
