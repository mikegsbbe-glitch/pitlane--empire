# PITLANE EMPIRE — static website

This repository contains the existing game as `index.html`. It is intended for static hosting on Netlify and can also be stored in GitHub for version history.

## Current checks

- The game is a single HTML file with its CSS and JavaScript inline.
- No separate local JavaScript, CSS, image, or audio file references were found in the HTML.
- The inline JavaScript passed `node --check` syntax validation.
- Responsive CSS rules for smaller screens are present.

These checks do not replace a real browser play-test. The game has not been confirmed working in every desktop/mobile browser from this packaging step.

## Publish using Netlify Drop

1. Download and extract the ZIP.
2. Open <https://app.netlify.com/drop> and sign in.
3. Drag the extracted project folder (the folder containing `index.html`) onto the upload area.
4. Open the URL Netlify provides and test the game.

## Publish using GitHub + Netlify

1. Create a repository on GitHub.
2. Upload `index.html`, `netlify.toml`, `.nojekyll`, and this README to the repository root.
3. In Netlify choose **Add new project** / **Import an existing project**, connect GitHub, and select the repository.
4. Build command: leave empty. Publish directory: `.`.
5. Deploy. Future commits to the selected branch trigger new deployments.

## Important limitations

- The game currently stores accounts and progress in browser `localStorage`; this is not secure authentication and does not sync between devices.
- The included `PITLANE 3065` reward code is client-side. A player who edits browser code can bypass it; do not use this version for competitive online economies.
- Publishing this static site does not implement cloud saves, Google sign-in, server-verified gift codes, live player tracking, protected host/developer roles, or the host-exclusive Senna McLaren.
- Do not add service-role keys, admin secrets, or private credentials to frontend files.

## Updating

Keep a backup before replacing `index.html`. Commit changes to GitHub and let Netlify deploy the selected branch, or re-upload the folder to the existing Netlify site.
